import React, { Children } from 'react';
import './styles.css';
import TwitterIcon from '../../images/icons/twitter-icon.png'
import MapsIcon from '../../images/icons/maps-icon.png'
import InstagramIcon from '../../images/icons/instagram-icon.png'

import TwitterCloud from '../../images/clouds/twitter-cloud.jpeg'
import InstagramCloud from '../../images/clouds/instagram-cloud.jpeg'
import MapsCloud from '../../images/clouds/maps-cloud.jpeg'


class Clouds extends React.Component {
    constructor(props) {
        super(props)
     
        this.state = {
            currentCloud:InstagramCloud,
            mapsVal:"Google",
            twitterVal:"Twitter",
            instagramVal:"Instagram"
        }
    }
    
    componentDidMount() {}

    componentDidUpdateComponentName() {}

    componentWillUnmount() {}


    changeCloud = (mediaName) => {
        switch(mediaName.target.alt){
            case "Twitter":
                console.log("Cambiamos a twitter")
                this.setState({
                    currentCloud:TwitterCloud
                })
            break;

            case "Instagram":
                console.log("Cambiamos a instagram")
                this.setState({
                    currentCloud:InstagramCloud
                })
            break;

            case "Google":
                console.log("Cambiamos a google")
                this.setState({
                    currentCloud:MapsCloud
                })
            break;

            default:
                console.log(mediaName)
            break;
        }
    }



    render() {
        return (
            <section id="section-b" className={`topic-cards-container ${this.props.reverse ? "topic-cards-container-reverse" : ""}`}>
                <div className="info-section">
                    <div className="info-content">
                        {/* {this.props.text} */}
                        {/* <img 
                            className="cloud-image"
                            alt={this.props.mediaName}
                            src={this.props.imagePath}
                        /> */}
                        <img 
                            className="cloud-image"
                            alt="twitter"
                            src={this.state.currentCloud}
                        />
                    </div>
                    {/* <img alt="icon" className="info-icon" src={"../../images/"+this.props.iconPath}/> */}
                </div>
                
                <div className="chart-section">
                    {/* <div className="cloud-selections-panel"> */}
                        <div className="cloud-selector" value="Google">
                            <img onClick={ this.changeCloud} alt="Google" src={MapsIcon}/>
                        </div>

                        <div className="cloud-selector" value="Twitter">
                            <img onClick={this.changeCloud} alt="Twitter" src={TwitterIcon}/>
                        </div>
                    {/* </div> */}

                    {/* <div className="cloud-selections-panel"> */}
                        <div className="cloud-selector" value="Instagram">
                            <img onClick={this.changeCloud} alt="Instagram" src={InstagramIcon}/>
                        </div>

                        {/* <div className="cloud-selector" value="None">
                            <p>BBVA Online</p>
                        </div> */}
                    {/* </div> */}
                       
                </div>
            </section>
        )
    }
}

export default Clouds;