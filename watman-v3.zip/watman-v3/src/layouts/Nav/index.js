import React from 'react'
import PropTypes from 'prop-types'
import './styles.css'
import { HashLink } from 'react-router-hash-link';

class Nav extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            
        }
    }
    
    componentDidMount() {}

    componentDidUpdate() {}

    componentWillUnmount() {}



    render() {
        let classNames = "nav-container "+this.props.extraClassName 
        return (
            <nav className={classNames}>
                <ul className="nav"> 
                    <li>
                        <HashLink smooth to="#section-a">
                            <span className="nav-option">
                                Gramática
                            </span>
                        </HashLink>
                    </li>

                    <li>
                        <HashLink smooth to="#section-b">
                            <span className="nav-option">
                                Redes Sociales
                            </span>
                        </HashLink>
                    </li>

                    <li>
                        <HashLink smooth to="#section-c">
                            <span className="nav-option">
                                Ge(oo)pinion
                            </span>
                        </HashLink>
                    </li>

                    <li>
                        <HashLink smooth to="#section-d">
                            <span className="nav-option">
                                Hola Watman
                            </span>
                        </HashLink>
                    </li>
                </ul>
            </nav>   
        )
    }
}

export default Nav