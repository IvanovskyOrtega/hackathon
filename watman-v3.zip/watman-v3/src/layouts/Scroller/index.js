import React from 'react'
import PropTypes from 'prop-types'
import './styles.css'
import { HashLink } from 'react-router-hash-link';
import Chart from '../../images/charts/post_tagging.svg'
// import SplitPane from "react-split-pane";
import HorizontalScroll from 'react-scroll-horizontal'

class Scroller extends React.Component {
    constructor(props) {
        super(props);
        this.state = {      
              value: '¿Tienes algo que compartir con nosotros??',
              resultados:{}
  
          };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
      }
    
    componentDidMount() {}

    componentDidUpdate() {}

    componentWillUnmount() {}

    
    
      handleChange(event) {    this.setState({value: event.target.value});  }
      handleSubmit(event) {
        alert('Gracias por compartir!: ' );
        event.preventDefault();
        this.setState({
          resultados:{
            "id_review": "c8d10413-2afb-474d-80b7-1410266bc640",
            "alphabetical_characters": 84,
            "total_characters": 103,
            "digits_count": 0,
            "emojis_count": 0,
            "hashtags_count": 1,
            "arrobas_count": 1,
            "lowercase_characters": 5,
            "uppercase_characters": 5,
            "total_spaces": 16,
            "special_characters": 3,
            "urls_count": 0,
            "whitespaces": 16,
            "total_tokens": 17,
            "hapaxes_count": 0,
            "stopwords_count": 8,
            "segment": "Cajeros automaticos",
            "encoded_svg": "PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB4bWw6bGFuZz0iZXMiIGlkPSI2YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wIiBjbGFzcz0iZGlzcGxhY3kiIHdpZHRoPSIxMjc1IiBoZWlnaHQ9IjM5OS41IiBkaXJlY3Rpb249Imx0ciIgc3R5bGU9Im1heC13aWR0aDogbm9uZTsgaGVpZ2h0OiAzOTkuNXB4OyBjb2xvcjogIzAwMDAwMDsgYmFja2dyb3VuZDogI2ZmZmZmZjsgZm9udC1mYW1pbHk6IEFyaWFsOyBkaXJlY3Rpb246IGx0ciI+Cjx0ZXh0IGNsYXNzPSJkaXNwbGFjeS10b2tlbiIgZmlsbD0iY3VycmVudENvbG9yIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiB5PSIzMDkuNSI+CiAgICA8dHNwYW4gY2xhc3M9ImRpc3BsYWN5LXdvcmQiIGZpbGw9ImN1cnJlbnRDb2xvciIgeD0iNTAiPmVzY3JpYmlyPC90c3Bhbj4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktdGFnIiBkeT0iMmVtIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9IjUwIj5WRVJCPC90c3Bhbj4KPC90ZXh0PgoKPHRleHQgY2xhc3M9ImRpc3BsYWN5LXRva2VuIiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHk9IjMwOS41Ij4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktd29yZCIgZmlsbD0iY3VycmVudENvbG9yIiB4PSIyMjUiPnBhdG88L3RzcGFuPgogICAgPHRzcGFuIGNsYXNzPSJkaXNwbGFjeS10YWciIGR5PSIyZW0iIGZpbGw9ImN1cnJlbnRDb2xvciIgeD0iMjI1Ij5OT1VOPC90c3Bhbj4KPC90ZXh0PgoKPHRleHQgY2xhc3M9ImRpc3BsYWN5LXRva2VuIiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHk9IjMwOS41Ij4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktd29yZCIgZmlsbD0iY3VycmVudENvbG9yIiB4PSI0MDAiPmRlc2NyYmlyPC90c3Bhbj4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktdGFnIiBkeT0iMmVtIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9IjQwMCI+UFJPUE48L3RzcGFuPgo8L3RleHQ+Cgo8dGV4dCBjbGFzcz0iZGlzcGxhY3ktdG9rZW4iIGZpbGw9ImN1cnJlbnRDb2xvciIgdGV4dC1hbmNob3I9Im1pZGRsZSIgeT0iMzA5LjUiPgogICAgPHRzcGFuIGNsYXNzPSJkaXNwbGFjeS13b3JkIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9IjU3NSI+bWFsPC90c3Bhbj4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktdGFnIiBkeT0iMmVtIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9IjU3NSI+QURKPC90c3Bhbj4KPC90ZXh0PgoKPHRleHQgY2xhc3M9ImRpc3BsYWN5LXRva2VuIiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHk9IjMwOS41Ij4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktd29yZCIgZmlsbD0iY3VycmVudENvbG9yIiB4PSI3NTAiPnNlcnZpY2lvPC90c3Bhbj4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktdGFnIiBkeT0iMmVtIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9Ijc1MCI+Tk9VTjwvdHNwYW4+CjwvdGV4dD4KCjx0ZXh0IGNsYXNzPSJkaXNwbGFjeS10b2tlbiIgZmlsbD0iY3VycmVudENvbG9yIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiB5PSIzMDkuNSI+CiAgICA8dHNwYW4gY2xhc3M9ImRpc3BsYWN5LXdvcmQiIGZpbGw9ImN1cnJlbnRDb2xvciIgeD0iOTI1Ij5jYWplcm88L3RzcGFuPgogICAgPHRzcGFuIGNsYXNzPSJkaXNwbGFjeS10YWciIGR5PSIyZW0iIGZpbGw9ImN1cnJlbnRDb2xvciIgeD0iOTI1Ij5OT1VOPC90c3Bhbj4KPC90ZXh0PgoKPHRleHQgY2xhc3M9ImRpc3BsYWN5LXRva2VuIiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiIHk9IjMwOS41Ij4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktd29yZCIgZmlsbD0iY3VycmVudENvbG9yIiB4PSIxMTAwIj5hdXRvbWF0aWNvPC90c3Bhbj4KICAgIDx0c3BhbiBjbGFzcz0iZGlzcGxhY3ktdGFnIiBkeT0iMmVtIiBmaWxsPSJjdXJyZW50Q29sb3IiIHg9IjExMDAiPkFESjwvdHNwYW4+CjwvdGV4dD4KCjxnIGNsYXNzPSJkaXNwbGFjeS1hcnJvdyI+CiAgICA8cGF0aCBjbGFzcz0iZGlzcGxhY3ktYXJjIiBpZD0iYXJyb3ctNmJhMTczYjM4OThhNDU5YjhjNjUzNjNmNWYzZDI2ZDMtMC0wIiBzdHJva2Utd2lkdGg9IjJweCIgZD0iTTcwLDI2NC41IEM3MCwxNzcuMCAyMTUuMCwxNzcuMCAyMTUuMCwyNjQuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiLz4KICAgIDx0ZXh0IGR5PSIxLjI1ZW0iIHN0eWxlPSJmb250LXNpemU6IDAuOGVtOyBsZXR0ZXItc3BhY2luZzogMXB4Ij4KICAgICAgICA8dGV4dFBhdGggeGxpbms6aHJlZj0iI2Fycm93LTZiYTE3M2IzODk4YTQ1OWI4YzY1MzYzZjVmM2QyNmQzLTAtMCIgY2xhc3M9ImRpc3BsYWN5LWxhYmVsIiBzdGFydE9mZnNldD0iNTAlIiBzaWRlPSJsZWZ0IiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiPm9iajwvdGV4dFBhdGg+CiAgICA8L3RleHQ+CiAgICA8cGF0aCBjbGFzcz0iZGlzcGxhY3ktYXJyb3doZWFkIiBkPSJNMjE1LjAsMjY2LjUgTDIyMy4wLDI1NC41IDIwNy4wLDI1NC41IiBmaWxsPSJjdXJyZW50Q29sb3IiLz4KPC9nPgoKPGcgY2xhc3M9ImRpc3BsYWN5LWFycm93Ij4KICAgIDxwYXRoIGNsYXNzPSJkaXNwbGFjeS1hcmMiIGlkPSJhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTEiIHN0cm9rZS13aWR0aD0iMnB4IiBkPSJNMjQ1LDI2NC41IEMyNDUsMTc3LjAgMzkwLjAsMTc3LjAgMzkwLjAsMjY0LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3VycmVudENvbG9yIi8+CiAgICA8dGV4dCBkeT0iMS4yNWVtIiBzdHlsZT0iZm9udC1zaXplOiAwLjhlbTsgbGV0dGVyLXNwYWNpbmc6IDFweCI+CiAgICAgICAgPHRleHRQYXRoIHhsaW5rOmhyZWY9IiNhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTEiIGNsYXNzPSJkaXNwbGFjeS1sYWJlbCIgc3RhcnRPZmZzZXQ9IjUwJSIgc2lkZT0ibGVmdCIgZmlsbD0iY3VycmVudENvbG9yIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5hbW9kPC90ZXh0UGF0aD4KICAgIDwvdGV4dD4KICAgIDxwYXRoIGNsYXNzPSJkaXNwbGFjeS1hcnJvd2hlYWQiIGQ9Ik0zOTAuMCwyNjYuNSBMMzk4LjAsMjU0LjUgMzgyLjAsMjU0LjUiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgo8L2c+Cgo8ZyBjbGFzcz0iZGlzcGxhY3ktYXJyb3ciPgogICAgPHBhdGggY2xhc3M9ImRpc3BsYWN5LWFyYyIgaWQ9ImFycm93LTZiYTE3M2IzODk4YTQ1OWI4YzY1MzYzZjVmM2QyNmQzLTAtMiIgc3Ryb2tlLXdpZHRoPSIycHgiIGQ9Ik01OTUsMjY0LjUgQzU5NSwxNzcuMCA3NDAuMCwxNzcuMCA3NDAuMCwyNjQuNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJjdXJyZW50Q29sb3IiLz4KICAgIDx0ZXh0IGR5PSIxLjI1ZW0iIHN0eWxlPSJmb250LXNpemU6IDAuOGVtOyBsZXR0ZXItc3BhY2luZzogMXB4Ij4KICAgICAgICA8dGV4dFBhdGggeGxpbms6aHJlZj0iI2Fycm93LTZiYTE3M2IzODk4YTQ1OWI4YzY1MzYzZjVmM2QyNmQzLTAtMiIgY2xhc3M9ImRpc3BsYWN5LWxhYmVsIiBzdGFydE9mZnNldD0iNTAlIiBzaWRlPSJsZWZ0IiBmaWxsPSJjdXJyZW50Q29sb3IiIHRleHQtYW5jaG9yPSJtaWRkbGUiPmFkdm1vZDwvdGV4dFBhdGg+CiAgICA8L3RleHQ+CiAgICA8cGF0aCBjbGFzcz0iZGlzcGxhY3ktYXJyb3doZWFkIiBkPSJNNTk1LDI2Ni41IEw1ODcsMjU0LjUgNjAzLDI1NC41IiBmaWxsPSJjdXJyZW50Q29sb3IiLz4KPC9nPgoKPGcgY2xhc3M9ImRpc3BsYWN5LWFycm93Ij4KICAgIDxwYXRoIGNsYXNzPSJkaXNwbGFjeS1hcmMiIGlkPSJhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTMiIHN0cm9rZS13aWR0aD0iMnB4IiBkPSJNNzAsMjY0LjUgQzcwLDIuMCA3NTAuMCwyLjAgNzUwLjAsMjY0LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3VycmVudENvbG9yIi8+CiAgICA8dGV4dCBkeT0iMS4yNWVtIiBzdHlsZT0iZm9udC1zaXplOiAwLjhlbTsgbGV0dGVyLXNwYWNpbmc6IDFweCI+CiAgICAgICAgPHRleHRQYXRoIHhsaW5rOmhyZWY9IiNhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTMiIGNsYXNzPSJkaXNwbGFjeS1sYWJlbCIgc3RhcnRPZmZzZXQ9IjUwJSIgc2lkZT0ibGVmdCIgZmlsbD0iY3VycmVudENvbG9yIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5vYmo8L3RleHRQYXRoPgogICAgPC90ZXh0PgogICAgPHBhdGggY2xhc3M9ImRpc3BsYWN5LWFycm93aGVhZCIgZD0iTTc1MC4wLDI2Ni41IEw3NTguMCwyNTQuNSA3NDIuMCwyNTQuNSIgZmlsbD0iY3VycmVudENvbG9yIi8+CjwvZz4KCjxnIGNsYXNzPSJkaXNwbGFjeS1hcnJvdyI+CiAgICA8cGF0aCBjbGFzcz0iZGlzcGxhY3ktYXJjIiBpZD0iYXJyb3ctNmJhMTczYjM4OThhNDU5YjhjNjUzNjNmNWYzZDI2ZDMtMC00IiBzdHJva2Utd2lkdGg9IjJweCIgZD0iTTc3MCwyNjQuNSBDNzcwLDE3Ny4wIDkxNS4wLDE3Ny4wIDkxNS4wLDI2NC41IiBmaWxsPSJub25lIiBzdHJva2U9ImN1cnJlbnRDb2xvciIvPgogICAgPHRleHQgZHk9IjEuMjVlbSIgc3R5bGU9ImZvbnQtc2l6ZTogMC44ZW07IGxldHRlci1zcGFjaW5nOiAxcHgiPgogICAgICAgIDx0ZXh0UGF0aCB4bGluazpocmVmPSIjYXJyb3ctNmJhMTczYjM4OThhNDU5YjhjNjUzNjNmNWYzZDI2ZDMtMC00IiBjbGFzcz0iZGlzcGxhY3ktbGFiZWwiIHN0YXJ0T2Zmc2V0PSI1MCUiIHNpZGU9ImxlZnQiIGZpbGw9ImN1cnJlbnRDb2xvciIgdGV4dC1hbmNob3I9Im1pZGRsZSI+bm1vZDwvdGV4dFBhdGg+CiAgICA8L3RleHQ+CiAgICA8cGF0aCBjbGFzcz0iZGlzcGxhY3ktYXJyb3doZWFkIiBkPSJNOTE1LjAsMjY2LjUgTDkyMy4wLDI1NC41IDkwNy4wLDI1NC41IiBmaWxsPSJjdXJyZW50Q29sb3IiLz4KPC9nPgoKPGcgY2xhc3M9ImRpc3BsYWN5LWFycm93Ij4KICAgIDxwYXRoIGNsYXNzPSJkaXNwbGFjeS1hcmMiIGlkPSJhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTUiIHN0cm9rZS13aWR0aD0iMnB4IiBkPSJNNzcwLDI2NC41IEM3NzAsODkuNSAxMDk1LjAsODkuNSAxMDk1LjAsMjY0LjUiIGZpbGw9Im5vbmUiIHN0cm9rZT0iY3VycmVudENvbG9yIi8+CiAgICA8dGV4dCBkeT0iMS4yNWVtIiBzdHlsZT0iZm9udC1zaXplOiAwLjhlbTsgbGV0dGVyLXNwYWNpbmc6IDFweCI+CiAgICAgICAgPHRleHRQYXRoIHhsaW5rOmhyZWY9IiNhcnJvdy02YmExNzNiMzg5OGE0NTliOGM2NTM2M2Y1ZjNkMjZkMy0wLTUiIGNsYXNzPSJkaXNwbGFjeS1sYWJlbCIgc3RhcnRPZmZzZXQ9IjUwJSIgc2lkZT0ibGVmdCIgZmlsbD0iY3VycmVudENvbG9yIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIj5hbW9kPC90ZXh0UGF0aD4KICAgIDwvdGV4dD4KICAgIDxwYXRoIGNsYXNzPSJkaXNwbGFjeS1hcnJvd2hlYWQiIGQ9Ik0xMDk1LjAsMjY2LjUgTDExMDMuMCwyNTQuNSAxMDg3LjAsMjU0LjUiIGZpbGw9ImN1cnJlbnRDb2xvciIvPgo8L2c+Cjwvc3ZnPg=="
             
          }
        })
      }


    render() {
        let classNames = "scroller-container "+this.props.extraClassName 
        // const child = { width: `100%`, height: `300px`}

        // style={{backgroundImage:"data:image/svg+xml;base64,"+this.state.newSegments.encoded_svg}}
        return (
            
            <div id="section-a" className={classNames}>
                {/* <HorizontalScroll> */}
                
                <h3>Categoría Gramatical</h3>
                <div class="tech-slideshow">

                    
                    <div class="mover-1" ></div>            
                </div>
                
                {/* <div className="slider">
                    <img alt="Post tagging chart" src={Chart}/>
                </div> */}
                {/* </HorizontalScroll> */}
                
                {/* <p className="pos-desc">
                    En lingüística computacional, el etiquetado gramatical 
                    (conocido también por su nombre en inglés, part-of-speech
                    tagging, POS tagging o POST) es el proceso de asignar 
                    (o etiquetar) a cada una de las palabras de un texto su 
                    categoría gramatical.
                </p> */}

                <span className="seg-subtitle">Un comentaio dice más que mil googleadas...</span>
                <form className="seg-form" onSubmit={this.handleSubmit}>
                    
                    <textarea className="seg-txtarea" value={this.state.value} onChange={this.handleChange} />
                    <input className="seg-subbtn" type="submit" value="Submit" />
                </form>


                 <table>
                    <tr>
                        <th># Segmento</th>
                        <th># Caracteres (alpha)</th>
                        <th># Caracteres totales</th>
                        <th># Emojis</th>
                        <th># Hashtags</th>
                        <th># URLs</th>
                        <th># Términos</th>
                    </tr>
                    <tr>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "Déjanos" : this.state.resultados.segment}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "Un" : this.state.resultados.alphabetical_characters}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "Comentario" : this.state.resultados.total_characters}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "En" : this.state.resultados.emojis_count}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "El" : this.state.resultados.hashtags_count}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "Formulario :)" : this.state.resultados.urls_count}</td>
                        <td>{(Object.keys(this.state.resultados).length===0) ? "Formulario :)" : this.state.resultados.total_tokens}</td>
                    </tr>
                    
                </table> 
            </div>   
        )
    }
}

export default Scroller
