import React, { Children } from 'react';
import './styles.css';

import Good from '../../images/icons/good.png'
import Bad from '../../images/icons/bad.png'
import Neutral from '../../images/icons/neutral.png'
import Comment from '../../images/icons/comment.png'


// import "../Segments/node_modules/react-loader-spinner/dist/loader/css/react-spinner-loader.css"
import Loader from 'react-loader-spinner'
import Axios from 'axios';

// class SentimentBox extends React.Component {
//     constructor(props) {
//         super(props)
     
//         this.state = {
//             formValue:'',
//             commentResults:{}
//         }
//     }
    
//     componentDidMount() {}

//     componentDidUpdate(prevProps, prevState) {
//         if(prevProps.commentResults !== this.props.commentResults) {
//             this.setState({
//                 commentResults:this.props.commentResults
//             })
//             console.log("updating results")
//         }

//     }

//     componentWillUnmount() {}

//     handleFormInput = (e) => {
//         this.setState({
//             formValue:e.target.value
//         })
//     }

//     handleFormInputInside(e){
//         console.log(e.target.value)
//         e.preventDefault()
//         this.setState({
//             formValue:e.target.value
//         })
//     }

//     // Submit comment
//     submitCommentInside(e){
//         console.log(e)
//         e.preventDefault()
//         let _comments = []
//         _comments.push(e.target.value)

//         // fake 
//         console.log(_comments)
//         this.setState({
//         commentResults:{
//             '0': {
//                 'prediction': 'negative',
//                 'confidence': 1.0000051
//             }
//         }
//         })
//     }

//     render() {
//         let resultsContent = null
//         console.log("comment res")
//         console.log(this.state.commentResults)
//         console.log(Object.keys(this.state.commentResults).length ===0)
//         if(Object.keys(this.state.commentResults).length ===0){
//             resultsContent = <Loader
//                 type="Puff"
//                 color="#00BFFF"
//                 height={100}
//                 width={100}
//                 timeout={1000000}
//              />
//         } else {
//             resultsContent = <React.Fragment>
//                 <span>
//                     {this.state.commentResults['0'].prediction}
//                 </span>
//                 <span>
//                     {this.state.commentResults['0'].confidence}
//                 </span>
//             </React.Fragment>
//         }

//         return (

//             <section className={`sentiment-panel ${this.props.reverse ? "topic-cards-container-reverse" : ""}`}>
//                 <form 
//                     className="form-container"
//                     onSubmit={(e)=>this.submitCommentInside}
//                 >
//                 <input type="text" name="comment"  
//                     onChange={this.handleFormInputInside}
//                 ></input>
//                 <input type="submit" value="Enviar"></input>
//                 </form>
                
//                 <div className="reults-panel">
//                     {this.state.formValue}
//                 </div>
//             </section>
//         )
//     }
// }

class SentimentBox extends React.Component {
    constructor(props) {
      super(props);
      this.state = {      
            value: '¿Qué opinas sobre nuestros servicios/productos?',
            resultados:{}

        };
      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleChange(event) {    this.setState({value: event.target.value}); console.log(this.state.value)  }
    handleSubmit(event) {
      alert('Tu opinión cuenta mucho!' );
      event.preventDefault();
    //   this.setState({
    //     resultados:{
    //         '0':{
    //             "sentiment":"negative "+String(Math.random())
    //         }
    //     }
    //   })
    Axios.post('http://c669524af66b.ngrok.io/sa', {
        comments:this.state.value
    }).then((res)=>{
        console.log(res)
    }).catch((err)=>{
        alert('Hubo problemas al procesar tu solicitud :(' );
    })
    }
  
    render() {
      return (
        <div id="section-d" className="sentiments-container">
            <span>Permite a Watman evaluar tus opiniones</span>
            <form className="sentiment-form" onSubmit={this.handleSubmit}>
                
                <textarea className="txtarea" value={this.state.value} onChange={this.handleChange} />
                <input className="subbtn" type="submit" value="Submit" />
            </form>

            <img alt="sentimiento" src={(Object.keys(this.state.resultados).length === 0) ? Comment:(this.state.resultados.prediction=="positive")? Good: Bad} />
            <span>{(Object.keys(this.state.resultados).length === 0)?"":this.state.resultados['0'].prediction}</span>
        </div>
      );
    }
  }

export default SentimentBox;