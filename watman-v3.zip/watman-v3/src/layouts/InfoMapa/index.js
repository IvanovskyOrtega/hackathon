import React from "react";
import Good from '../../images/icons/good.png'
import Bad from '../../images/icons/bad.png'
import Neutral from '../../images/icons/neutral.png'
import './styles.css';

class InfoMapa extends React.Component {
    render() {
        const extraClasses = "info-mapa-bottom "+this.props.extraClassName
        return(
            <div className="info-mapa-seccion">
                <div className="info-mapa-icon">
                    <img alt="good" src={Good}/>
                    <span>Mayor a 3.6</span>
                </div>

                <div className="info-mapa-icon">
                    <img alt="good" src={Neutral}/>
                    <span>Neutral</span>
                </div>

                <div className="info-mapa-icon">
                    <img alt="bad" src={Bad}/>
                    <span>Menor a 2.5</span>
                </div>
            </div>
        )
    }
}

export default InfoMapa