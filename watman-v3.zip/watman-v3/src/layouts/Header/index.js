import React from 'react'
import PropTypes from 'prop-types'
import './styles.css'
import Logo from '../../images/logo/logo.jpg'

class Header extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            
        }
    }
    
    componentDidMount() {}

    componentDidUpdate() {}

    componentWillUnmount() {}



    render() {
        let classNames = "header "+this.props.extraClassName 
        return (
            <header className={classNames}>
                <img alt="watman logo" src={Logo}/>
                {/* <button 
                    value="btn value" 
                    onClick={this.props.changeSomething.bind(this)}>
                        Change Something
                </button> */}
                
                {/* <p>
                    {this.props.something}
                </p> */}
            </header>   
        )
    }
}

export default Header