import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react';
import Data from "../../assets/data/results.json"; 

import GoodIcon from '../../images/icons/good.png'
import BadIcon from '../../images/icons/bad.png'
import NeutralIcon from '../../images/icons/neutral.png'

const AnyReactComponent = ({ icon }) => <img className="inner-map-icon" alt="loquesea" src={icon} />//<div>{text}</div>;
 
class Map extends Component {
  static defaultProps = {
    center: {
      lat: 19.3967711,
      lng: -99.1615616
    },
    zoom: 14
  };
 
  state = {
    dataPoints:[]
  }

  componentDidMount() {
    this.setState({
        dataPoints:Data.results
    })
  }

  render() {
    let classNames = "aux-container "+this.props.extraClassName 
    return (
      // Important! Always set the container height explicitly
      <div id="section-c" className={classNames}>
        
        <div className="map-container" style={{ height: '60vh', width: '100%' }}>
          <GoogleMapReact
            bootstrapURLKeys={{ key:"AIzaSyAMHoGQZiF-a_iKRtt3oFbB7NJbF3ORB_0"}}
            defaultCenter={this.props.center}
            defaultZoom={this.props.zoom}
          >
          {
              this.state.dataPoints.map((location)=> (
                  <AnyReactComponent
                      
                      lat={location.lalitud}
                      lng={location.longitud}
                      icon={(location.rating<2.5)?BadIcon:(location.rating>=2.5 && location.rating<=3.8)?NeutralIcon:GoodIcon}
                  />
              ))
          }
          </GoogleMapReact>
        </div>
        
      </div>
    );
  }
}
 
export default Map;