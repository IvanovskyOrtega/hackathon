import React, { Children } from 'react';
import './styles.css';

import "react-loader-spinner/dist/loader/css/react-spinner-loader.css"
import Loader from 'react-loader-spinner'

class SentimentBox extends React.Component {
    constructor(props) {
        super(props)
     
        this.state = {
            formValue:'',
            commentResults:{}
        }
    }
    
    componentDidMount() {}

    componentDidUpdate(prevProps, prevState) {
        if(prevProps.commentResults !== this.props.commentResults) {
            this.setState({
                commentResults:this.props.commentResults
            })
            console.log("updating results")
        }

    }

    componentWillUnmount() {}

    handleFormInput = (e) => {
        this.setState({
            formValue:e.target.value
        })
    }

    render() {
        let resultsContent = null
        console.log("comment res")
        console.log(this.state.commentResults)
        console.log(Object.keys(this.state.commentResults).length ===0)
        if(Object.keys(this.state.commentResults).length ===0){
            resultsContent = <Loader
                type="Puff"
                color="#00BFFF"
                height={100}
                width={100}
                timeout={1000000}
             />
        } else {
            resultsContent = <React.Fragment>
                <span>
                    {this.state.commentResults['0'].prediction}
                </span>
                <span>
                    {this.state.commentResults['0'].confidence}
                </span>
            </React.Fragment>
        }

        return (

            <section className={`sentiment-panel ${this.props.reverse ? "topic-cards-container-reverse" : ""}`}>
                <form 
                    className="form-container"
                    onSubmit={this.props.submitComment.bind(this, this.state.formValue)}
                >
                <textarea name="textarea" rows="10" cols="50" 
                    value={this.state.formValue}
                    onChange={(e)=>this.handleFormInput}
                >
                    ¿Qué opinas de nuestros productos y/o servicios?
                </textarea>
                <input type="submit" value="Enviar"></input>
                </form>
                
                <div className="reults-panel">
                    
                </div>
            </section>
        )
    }
}

export default SentimentBox;