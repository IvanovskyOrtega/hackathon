import React from 'react';
import './Footer.css';


class Footer extends React.Component {
    state = {

    }

    render() {
        const classNames = "footer "+this.props.extraClassName

        return (
            <footer className={classNames}>
                WATMAN BY @HIGH TECH TEAM
            </footer>
        )
    }
}

export default Footer;