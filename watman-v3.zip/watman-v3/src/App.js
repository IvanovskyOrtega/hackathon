import React from 'react';
import logo from './logo.svg';
import './App.css';
import Axios from 'axios';

// layouts
import Header from './layouts/Header'
import Nav from './layouts/Nav'
import Scroller from "./layouts/Scroller"
import Map from "./layouts/Map"
import Clouds from "./layouts/Clouds"
import SentimentBox from "./layouts/SentimentBox";
import Footer  from "./layouts/Footer";
import InfoMapa from "./layouts/InfoMapa";



class App extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      commentResults:{},
      something:"soemthing",
    }
  }  
  // Submit comment
  submitComment = (comment) => {
    let _comments = []
    _comments.push(comment)

    // fake 
    console.log(_comments)
    this.setState({
      commentResults:{
        '0': {
            'prediction': 'negative',
            'confidence': 1.0000051
        }
      }
    })

    // Axios.post("http://", {
    //   comments:_comments
    // }).then((res)=>{
    //   this.setState({
    //     commentResults:res.data
    //   })
    // })
  }
  
  // Get word cloud
  getWordCloud = (socialMedia) => {
    Axios.post("http://",{
      mediaName:socialMedia
    }).then((res)=>{
      this.setState({
        commentResults:res.data
      })
    })
  }

  // fakeFunction changeSomething
  changeSomething = () => {
    let s = "NewValue"
    console.log(s)
    this.setState({
      something:"Hola " + s
    })
  }
  
  render() {
    return (
      <div className="App app-wrapper ">
        <Header 
          extraClassName={"container"}
          something={this.state.something}
          changeSomething={this.changeSomething}/>

        <Nav extraClassName={"container"}/>

        
        <Scroller extraClassName={"container"}/>
        
        <Clouds />

        <Map extraClassName={"container"}/>

        <InfoMapa extraClassName={"container"}/>

        <SentimentBox 
          submitComment={this.submitComment}
          commentResults={this.state.commentResults}
        />

        <Footer extraClassName={"container"}/>
      </div>
    )
  }
}

export default App;
